package com.app.controle.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.controle.models.Professor;



public interface ProfessorRepository extends JpaRepository<Professor, Long>{

}
