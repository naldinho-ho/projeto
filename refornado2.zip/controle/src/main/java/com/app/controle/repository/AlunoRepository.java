package com.app.controle.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.controle.models.Aluno;


public interface AlunoRepository extends JpaRepository<Aluno, Long> {

}
