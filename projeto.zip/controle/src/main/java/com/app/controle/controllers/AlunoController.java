package com.app.controle.controllers;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.app.controle.models.Aluno;
import com.app.controle.repository.AlunoRepository;
import com.app.controle.repository.CidadeRepository;




@Controller
public class AlunoController {
	@Autowired
	private AlunoRepository repository;
	
	@Autowired
	public CidadeRepository repositoryCidade;

	@GetMapping("/aluno")
	public ModelAndView findAll() {
		
		ModelAndView mv = new ModelAndView("/alunoTabela");
		mv.addObject("aluno", repository.findAll());
		
		return mv;
	}
	
	@GetMapping("/adicionarAluno")
	public ModelAndView add(Aluno aluno) {
		
		ModelAndView mv = new ModelAndView("/cadastrarAluno");
		mv.addObject("aluno",aluno);
		
		return mv;
	}
	
	@GetMapping("/editarAluno/{id}")
	public ModelAndView editar(@PathVariable("id") Long id) {
		Optional<Aluno> aluno = repository.findById(id);
		Aluno alu = aluno.get();
		
		
		return add(alu);
	}
	
	@GetMapping("/removerAluno/{id}")
	public ModelAndView delete(@PathVariable("id") Long id) {
		Optional<Aluno> aluno = repository.findById(id);
		Aluno alu = aluno.get();
		repository.delete(alu);
		
		return findAll();
	}
	
	@PostMapping("/salvarAluno")
	public ModelAndView save(@Valid Aluno aluno, BindingResult result) {
		if (result.hasErrors()) {
			return add(aluno);
		}
		repository.saveAndFlush(aluno);
		
		return findAll();
	}
}
