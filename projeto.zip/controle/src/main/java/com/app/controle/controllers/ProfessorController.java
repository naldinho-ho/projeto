package com.app.controle.controllers;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.app.controle.models.Professor;
import com.app.controle.repository.ProfessorRepository;

@Controller
public class ProfessorController {
	@Autowired
	private ProfessorRepository repository;

	@GetMapping("/professor")
	public ModelAndView findAll() {
		
		ModelAndView mv = new ModelAndView("/professorTabela");
		mv.addObject("professor", repository.findAll());
		
		return mv;
	}
	
	@GetMapping("/cadastroProfessor")
	public ModelAndView add(Professor professor) {
		
		ModelAndView mv = new ModelAndView("/addProfessor");
		mv.addObject("professor",professor);
		
		return mv;
	}
	
	@GetMapping("/editarProfessor/{id}")
	public ModelAndView editar(@PathVariable("id") Long id) {
		Optional<Professor> professor = repository.findById(id);
		Professor p = professor.get();
		
		
		return add(p);
	}
	
	@GetMapping("/removerProfessor/{id}")
	public ModelAndView delete(@PathVariable("id") Long id) {
		Optional<Professor> professor = repository.findById(id);
		Professor p = professor.get();
		repository.delete(p);
		
		return findAll();
	}
	
	@PostMapping("/salvarProfessor")
	public ModelAndView save(@Valid Professor professor, BindingResult result) {
		if (result.hasErrors()) {
			return add(professor);
		}
		repository.saveAndFlush(professor);
		
		return findAll();
	}

}
