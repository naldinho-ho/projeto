package com.app.controle.controllers;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.app.controle.models.Diretor;
import com.app.controle.repository.CidadeRepository;
import com.app.controle.repository.DiretorRepository;

@Controller
public class DiretorController {
	@Autowired
	private DiretorRepository repository;
	
	@Autowired
	public CidadeRepository repositoryCidade;

	@GetMapping("/diretor")
	public ModelAndView findAll() {
		
		ModelAndView mv = new ModelAndView("/diretorTabela");
		mv.addObject("diretor", repository.findAll());
		
		return mv;
	}
	
	@GetMapping("/addDiretor")
	public ModelAndView add(Diretor diretor) {
		
		ModelAndView mv = new ModelAndView("/cadastrarDiretor");
		mv.addObject("diretor",diretor);
		
		return mv;
	}
	
	@GetMapping("/editarDiretor/{id}")
	public ModelAndView editar(@PathVariable("id") Long id) {
		Optional<Diretor> diretor = repository.findById(id);
		Diretor d = diretor.get();
		
		
		return add(d);
	}
	
	@GetMapping("/removerDiretor/{id}")
	public ModelAndView delete(@PathVariable("id") Long id) {
		Optional<Diretor> diretor = repository.findById(id);
		Diretor d = diretor.get();
		repository.delete(d);
		
		return findAll();
	}
	
	@PostMapping("/salvarDiretor")
	public ModelAndView save(@Valid Diretor diretor, BindingResult result) {
		if (result.hasErrors()) {
			return add(diretor);
		}
		repository.saveAndFlush(diretor);
		
		return findAll();
	}
}

