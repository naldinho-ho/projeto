package com.app.controle.controllers;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.app.controle.models.Aluno;
import com.app.controle.repository.AlunoRepository;
import com.app.controle.repository.CidadeRepository;


@Controller
public class AlunoController {
	@Autowired
	private AlunoRepository repositoryAluno;
	
	@Autowired
	public CidadeRepository repositoryCidade;
	
	@GetMapping("/listarAluno")
	public ModelAndView listar() {
		ModelAndView mv = new ModelAndView("/aluno");
		mv.addObject("aluno", repositoryAluno.findAll());
		return mv;
	}
	
	@GetMapping("/adicionarAluno")
	public ModelAndView add(Aluno aluno) {
		ModelAndView mv = new ModelAndView("/addaluno");
		mv.addObject("aluno", aluno);
		mv.addObject("cidades", repositoryCidade.findAll());
		return mv;
	}
	
	@GetMapping("/editarAluno/{id}")
	public ModelAndView editar(@PathVariable("id") long id) {
		Optional<Aluno> op = repositoryAluno.findById(id);
		Aluno alu = op.get();
		return add(alu);
	}
	
	@GetMapping("/removerAluno/{id}")
	public ModelAndView remover(@PathVariable("id") long id) {
		Optional<Aluno> op = repositoryAluno.findById(id);
		Aluno alu = op.get();
		repositoryAluno.delete(alu);
		return listar();
	}
	
	@PostMapping("/salvarAluno")
	public ModelAndView salvar(Aluno aluno) {
		repositoryAluno.save(aluno);
		return listar();
	}

}
